#include <stdio.h>
#include <stdlib.h>

struct Node{
    int data;
    struct Node * next;
};

void linkedlisttravesal(struct Node * ptr){
    while(ptr!=NULL){
        printf("Data: %d \n", ptr->data);
        ptr = ptr->next;
    }
}

// Insertion:
struct Node * insertAtIndex(struct Node* head, int data, int index){
    struct Node * ptr = (struct Node *)malloc(sizeof(struct Node));
    struct Node * p = head;
    if(index==1){
        ptr->next = head;
        ptr->data = data;
        head = ptr;
        return head;
    }
    for(int i = 1; i<index-1; i++){
        p = p->next;
    }
    ptr->next = p->next;
    p->next = ptr;
    ptr->data = data;
    return head;
}

// Deletion:
struct Node * delAtIndex(struct Node * head, int index){
    struct Node * p = head;
    if(index==1){
        struct Node * ptr = head;
        head = ptr->next;
        free(ptr);
        return head;
    }
    for(int i = 1; i<index-1; i++){
        p = p->next;
    }
    struct Node * ptr = p->next;
    p->next = ptr->next;
    free(ptr);
    return head;
}

struct Node * reverseLL(struct Node * head){
    struct Node * ptr1 = head;
    struct Node * ptr2 = head->next;
    ptr1->next = NULL;
    struct Node * pt;
    for(int i = 1; ptr2->next!=NULL ; i++){
        pt = ptr2->next;
        ptr2->next = ptr1;
        ptr1 = ptr2;
        ptr2 = pt;
    }
    ptr2->next = ptr1;
    head = ptr2;
    return head;
}



int main(){
    struct Node * head;
    struct Node * second;
    struct Node * third;
    struct Node * fourth;

    head = (struct Node *)malloc(sizeof(struct Node));
    second = (struct Node *)malloc(sizeof(struct Node));
    third = (struct Node *)malloc(sizeof(struct Node));
    fourth = (struct Node *)malloc(sizeof(struct Node));

    head->data = 12;
    head->next = second;

    second->data = 22;
    second->next = third;

    third->data = 32;
    third->next = fourth;

    fourth->data = 42;
    fourth->next = NULL;

    printf("Before Insertion:\n");
    linkedlisttravesal(head);
    printf("\n");

    // Insertion:
    head = insertAtIndex(head, 44, 3);
    printf("After Insertion:\n");
    linkedlisttravesal(head);
    printf("\n");

    // Deletion:
    head = delAtIndex(head, 3);
    printf("After Deletion:\n");
    linkedlisttravesal(head);
    printf("\n");

    head = reverseLL(head);
    printf("After Reversal:\n");
    linkedlisttravesal(head);
    printf("\n");

    

}
