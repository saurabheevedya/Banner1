#include <stdio.h>
#include <stdlib.h>

struct Node{
    float coef;
    int expo;
    struct Node * next;
};

void print(struct Node * ptr){
    if(ptr == NULL){
        printf("No Polynomial");
    }
    else{
       while(ptr != NULL){
        printf("(%.1fx^%d)", ptr->coef, ptr->expo);
        ptr = ptr->next;
        if(ptr!=NULL){
            printf(" + ");
        }
        else{
            printf("\n");
        }
       } 
    }
}

struct Node* insert(struct Node* head, float coef, int expo){
    struct Node * temp = (struct Node *)malloc(sizeof(struct Node));
    struct Node* newP = (struct Node *)malloc(sizeof(struct Node));
    newP->coef = coef;
    newP->expo = expo;
    newP->next = NULL;
    if(head == NULL || expo > head->expo){
        newP->next = head;
        head = newP;
    }
    else{
        temp = head;
        while(temp->next!=NULL && temp->next->expo > expo){
            temp = temp->next;
        }
        newP->next = temp->next;
        temp->next = newP;
    }
    return head;
}

struct Node* create(struct Node* head){
    int n;
    int i;
    float coef;
    int expo;
    printf("Enter number of terms: ");
    scanf("%d", &n);
    for(i=0; i<n; i++){
        printf("Enter coeff of term %d: ", i+1);
        scanf("%f", &coef);
        printf("Enter expo of term %d: ", i+1);
        scanf("%d", &expo);
        head = insert(head, coef, expo);
    }
    return head;
}

int main(){
    struct Node* head = NULL;
    printf("Enter the polynomial\n");
    head = create(head);
    print(head);
}