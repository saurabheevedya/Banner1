#include <stdio.h>
#include <stdlib.h>
// #include <iostream>
// using namespace std;

struct Node{
    float coef;
    int expo;
    struct Node * next;
};

void print(struct Node * ptr){
    if(ptr == NULL){
        printf("No Polynomial");
    }
    else{
       while(ptr != NULL){
        printf("(%.1fx^%d)", ptr->coef, ptr->expo);
        ptr = ptr->next;
        if(ptr!=NULL){
            printf(" + ");
        }
        else{
            printf("\n");
        }
       } 
    }
}

struct Node* insert(struct Node* head, float coef, int expo){
    struct Node * temp = (struct Node *)malloc(sizeof(struct Node));
    struct Node* newP = (struct Node *)malloc(sizeof(struct Node));
    newP->coef = coef;
    newP->expo = expo;
    newP->next = NULL;
    if(head == NULL || expo > head->expo){
        newP->next = head;
        head = newP;
    }
    else if(expo == head->expo){
        head->coef += coef;
    }
    else{
        temp = head;
        while(temp->next!=NULL && temp->next->expo >= expo){
            temp = temp->next;
        }
        if(temp->expo == expo){
            temp->coef += coef;
        }
        else{
            newP->next = temp->next;
            temp->next = newP;
        }
        
    }
    return head;
}

struct Node* create(struct Node* head){
    int n;
    int i;
    float coef;
    int expo;
    printf("Enter number of terms: ");
    scanf("%d", &n);
    for(i=0; i<n; i++){
        printf("Enter coeff of term %d: ", i+1);
        scanf("%f", &coef);
        printf("Enter expo of term %d: ", i+1);
        scanf("%d", &expo);
        head = insert(head, coef, expo);
    }
    return head;
}

struct Node* add(struct Node* head1, struct Node* head2){
    struct Node* temp1 = head1;
    struct Node* temp2 = head2;
    struct Node* addition = (struct Node *)malloc(sizeof(struct Node));
    struct Node* addhead = addition;

    if(head1 == NULL && head2 == NULL){
        printf("Zero Polynomial\n");
        return NULL;
    }
    
    while(temp1 != NULL && temp2 != NULL){
        if(temp1->expo == temp2->expo){
            addition->expo = temp1->expo;
            addition->coef = temp1->coef + temp2->coef;
            temp1 = temp1->next;
            temp2 = temp2->next;
            if(temp1 != NULL || temp2 != NULL){
            addition->next = (struct Node *)malloc(sizeof(struct Node));
            addition = addition->next;
            }
        }
        else if(temp1->expo > temp2->expo){
            addition->expo = temp1->expo;
            addition->coef = temp1->coef;
            temp1 = temp1->next;
            if(temp1 != NULL && temp2 != NULL){
            addition->next = (struct Node *)malloc(sizeof(struct Node));
            addition = addition->next;
            }
        }
        else{
            addition->expo = temp2->expo;
            addition->coef = temp2->coef;
            temp2 = temp2->next;
            if(temp1 != NULL && temp2 != NULL){
            addition->next = (struct Node *)malloc(sizeof(struct Node));
            addition = addition->next;
            }
        }
    }
    while(temp1 != NULL){
        addition->expo = temp1->expo;
        addition->coef = temp1->coef;
        temp1 = temp1->next;
        if(temp1 != NULL){
            addition->next = (struct Node *)malloc(sizeof(struct Node));
            addition = addition->next;
        }
    }
    while(temp2 != NULL){
        addition->expo = temp2->expo;
        addition->coef = temp2->coef;
        temp2 = temp2->next;
        if(temp1 != NULL){
            addition->next = (struct Node *)malloc(sizeof(struct Node));
            addition = addition->next;
        }
    }
    addition->next = NULL;
    return addhead;
}
 
struct Node* sub(struct Node* head1, struct Node* head2){
    struct Node* temp1 = head1;
    struct Node* temp2 = head2;
    struct Node* subtraction = (struct Node *)malloc(sizeof(struct Node));
    struct Node* subhead = subtraction;

    if(head1 == NULL && head2 == NULL){
        printf("Zero Polynomial\n");
        return NULL;
    }

    while(temp1 != NULL && temp2 != NULL){
        if(temp1->expo == temp2->expo){
            subtraction->expo = temp1->expo;
            subtraction->coef = temp1->coef - temp2->coef;
            temp1 = temp1->next;
            temp2 = temp2->next;
            if(temp1 != NULL || temp2 != NULL){
            subtraction->next = (struct Node *)malloc(sizeof(struct Node));
            subtraction = subtraction->next;
            }
        }
        else if(temp1->expo > temp2->expo){
            subtraction->expo = temp1->expo;
            subtraction->coef = temp1->coef;
            temp1 = temp1->next;
            if(temp1 != NULL && temp2 != NULL){
            subtraction->next = (struct Node *)malloc(sizeof(struct Node));
            subtraction = subtraction->next;
            }
        }
        else{
            subtraction->expo = temp2->expo;
            subtraction->coef = -temp2->coef;
            temp2 = temp2->next;
            if(temp1 != NULL && temp2 != NULL){
            subtraction->next = (struct Node *)malloc(sizeof(struct Node));
            subtraction = subtraction->next;
            }
        }
    }
    while(temp1 != NULL){
        subtraction->expo = temp1->expo;
        subtraction->coef = temp1->coef;
        temp1 = temp1->next;
        if(temp1 != NULL){
            subtraction->next = (struct Node *)malloc(sizeof(struct Node));
            subtraction = subtraction->next;
        }
    }
    while(temp2 != NULL){
        subtraction->expo = temp2->expo;
        subtraction->coef = -(temp2->coef);
        temp2 = temp2->next;
        if(temp1 != NULL){
            subtraction->next = (struct Node *)malloc(sizeof(struct Node));
            subtraction = subtraction->next;
        }
    }
    subtraction->next = NULL;
    return subhead;
}
 
struct Node* multi(struct Node* head1, struct Node* head2){
    struct Node* temp1 = head1;
    struct Node* temp2 = head2;
    struct Node* multi = NULL;
    if(head1 == NULL && head2 == NULL){
        printf("Zero Polynomial\n");
        return NULL;
    }
    while(temp1 != NULL){
        while(temp2 != NULL){
            multi = insert(multi, temp1->coef * temp2->coef, temp1->expo + temp2->expo);
            temp2 = temp2->next;
        }
        temp2 = head2;
        temp1 = temp1->next;
    }
    temp1 = head1;
    return multi;
}

int main(){
    struct Node* head1 = NULL;
    struct Node* head2 = NULL;
    struct Node* head = NULL;

    printf("Enter the polynomial 1\n");
    head1 = create(head1);
    
    printf("Enter the polynomial 2\n");
    head2 = create(head2);
    
    struct Node* addhead = add(head1, head2);
    struct Node* subhead = sub(head1, head2);
    struct Node* multihead = multi(head1, head2);

    printf("Polynomial 1:\n");
    print(head1);
    printf("Polynomial 2:\n");
    print(head2);

    printf("Addition Polynomial:\n");
    print(addhead);
    printf("Subtraction Polynomial:\n");
    print(subhead);
    printf("Multiplication Polynomial:\n");
    print(multihead);
}