#include <stdio.h>
#define M 10
            // Increasing Address value by (u + i*i)%size, i++, 0 < i < size-1
            // where u is value genereted after using hash function

int hash_function(int n){
    return (2*n + 3)%M;
}

void insert(int num, int hashtable[]){
    for(int j=0; j<(M-1); j++ ){
            if(hashtable[(hash_function(num) + (j*j))%M] == 0){
                hashtable[(hash_function(num) + (j*j))%M] = num;
                break;
            }
        }
}

int search(int num, int hashtable[]){
    int address = -1;
    for(int j=0; j<(M-1); j++ ){
        if(hashtable[(hash_function(num) + (j*j))%M] == num){
            address = (hash_function(num) + (j*j))%M;
            break;
        }
    }
    return address;
}

int main(){
    int arr[] = {3, 2, 9, 6, 11, 13, 7, 12};
    int hashtable[M] = {0};
    
    for(int i=0; i<8; i++){
        insert(arr[i], hashtable);
    }

    for(int i=0; i<M; i++){
        printf("address %d: value %d \n", i, hashtable[i]);
    }

    printf("\n12 is at address: %d \n", search(12, hashtable));

    return 0;
}


