#include <stdio.h>
#include <stdlib.h>

// Employee record structure
struct Employee {
    int id;
    char name[50];
    float salary;
};

// Function to generate Fibonacci series up to a given limit
int* generateFibonacciSeries(int limit) {
    int* series = (int*)malloc(sizeof(int) * limit);
    series[0] = 0;
    series[1] = 1;
    for (int i = 2; i < limit; i++) {
        series[i] = series[i-1] + series[i-2];
    }
    return series;
}

// Fibonacci search function without recursion
int fibonacciSearch(struct Employee* employees, int n, int id) {
    int* fib = generateFibonacciSeries(n);
    int offset = -1;
    int i = 0;
    while (fib[i] < n) {
        i++;
    }
    while (i > 1) {
        int index = (offset + fib[i-2] < n-1) ? offset + fib[i-2] : n-1;
        if (employees[index].id < id) {
            i--;
            offset = index;
        } else if (employees[index].id > id) {
            i -= 2;
        } else {
            free(fib);
            return index;
        }
    }
    if (employees[offset+1].id == id) {
        free(fib);
        return offset+1;
    }
    free(fib);
    return -1;
}

// Fibonacci search function with recursion
int fibonacciSearchRecursive(struct Employee* employees, int n, int id, int* fib, int i, int offset) {
    if (fib[i] >= n) {
        i--;
        if (fib[i] >= n) {
            return fibonacciSearchRecursive(employees, n, id, fib, i-1, offset);
        }
    }
    int index = (offset + fib[i-1] < n-1) ? offset + fib[i-1] : n-1;
    if (employees[index].id < id) {
        return fibonacciSearchRecursive(employees, n, id, fib, i-2, index);
    } else if (employees[index].id > id) {
        if (i == 1) {
            return -1;
        }
        return fibonacciSearchRecursive(employees, n, id, fib, i-1, offset);
    } else {
        return index;
    }
}

int main() {
    // Create a pool of employee records
    struct Employee employees[] = {
        {101, "John Doe", 5000},
        {102, "Jane Smith", 6000},
        {103, "Bob Johnson", 5500},
        {104, "Mary Brown", 7000},
        {105, "Jim Green", 4500},
        {106, "Karen White", 8000},
        {107, "Mike Davis", 6500},
        {108, "Lisa Lee", 7500},
        {109, "Tim Jones", 4000},
        {110, "Sarah Black", 9000}
    };
    int n = sizeof(employees) / sizeof(employees[0]);
    int id = 110;

    // Perform Fibonacci search without recursion
    int index = fibonacciSearch(employees, n, id);
    if (index == -1) {
        printf("Employee with ID %d not found\n", id);
    } else {
        printf("Employee with ID %d found at index %d.\n", id, index);
    }

    // Perform Fibonacci search with recursion
    int* fib = generateFibonacciSeries(n);
    index = fibonacciSearchRecursive(employees, n, id, fib, n, -1);
    free(fib);
    if (index == -1) {
        printf("Employee with ID %d not found!\n", id);
    } else {
        printf("Employee with ID %d found at index %d.\n", id, index);
    }

    return 0;
}
