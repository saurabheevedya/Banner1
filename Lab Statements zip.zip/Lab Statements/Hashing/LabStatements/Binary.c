#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Student record structure
struct student {
    char name[20];
    int roll_no;
    float cgpa;
};

// Binary search function (recursive)
int binary_search_rec(struct student students[], int left, int right, char key[]) {
    if (left > right) {
        return -1;
    }
    int mid = (left + right) / 2;
    if (strcmp(students[mid].name, key) == 0) {
        return mid;
    } else if (strcmp(students[mid].name, key) < 0) {
        return binary_search_rec(students, mid + 1, right, key);
    } else {
        return binary_search_rec(students, left, mid - 1, key);
    }
}

// Binary search function (non-recursive)
int binary_search(struct student students[], int n, char key[]) {
    int left = 0;
    int right = n - 1;
    while (left <= right) {
        int mid = (left + right) / 2;
        if (strcmp(students[mid].name, key) == 0) {
            return mid;
        } else if (strcmp(students[mid].name, key) < 0) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return -1;
}

int main() {
    // Create student records
    struct student students[] = {
        {"Alice", 101, 8.5},
        {"Bob", 102, 9.0},
        {"Charlie", 103, 7.5},
        {"David", 104, 9.5},
        {"Emily", 105, 8.0}
    };
    int n = sizeof(students) / sizeof(students[0]);

    // Search for a student record using binary search (recursive)
    char key[20] = "David";
    int index_rec = binary_search_rec(students, 0, n - 1, key);
    if (index_rec == -1) {
        printf("Student record not found\n");
    } else {
        printf("Student record found at index %d\n", index_rec);
        printf("Name: %s\n", students[index_rec].name);
        printf("Roll No: %d\n", students[index_rec].roll_no);
        printf("CGPA: %.2f\n", students[index_rec].cgpa);
    }

    // Search for a student record using binary search (non-recursive)
    strcpy(key, "Emily");
    int index = binary_search(students, n, key);
    if (index == -1) {
        printf("Student record not found\n");
    } else {
        printf("Student record found at index %d\n", index);
        printf("Name: %s\n", students[index].name);
        printf("Roll No: %d\n", students[index].roll_no);
        printf("CGPA: %.2f\n", students[index].cgpa);
    }

    return 0;
}
