#include <stdio.h>
#include <stdlib.h>

// Binary Search Tree Node
struct bst_node {
    int data;
    struct bst_node *left;
    struct bst_node *right;
};

// Create new BST node
struct bst_node* new_node(int data) {
    struct bst_node* node = (struct bst_node*) malloc(sizeof(struct bst_node));
    node->data = data;
    node->left = NULL;
    node->right = NULL;
    return node;
}

// Create mirror image of a BST
struct bst_node* create_mirror_image(struct bst_node* root) {
    if (root == NULL) {
        return NULL;
    }
    struct bst_node* mirror = new_node(root->data);
    mirror->left = create_mirror_image(root->right);
    mirror->right = create_mirror_image(root->left);
    return mirror;
}

// Inorder traversal of BST
void inorder(struct bst_node* root) {
    if (root == NULL) {
        return;
    }
    inorder(root->left);
    printf("%d ", root->data);
    inorder(root->right);
}

int main() {
    // Create a BST
    struct bst_node* root = new_node(4);
    root->left = new_node(2);
    root->right = new_node(6);
    root->left->left = new_node(1);
    root->left->right = new_node(3);
    root->right->left = new_node(5);
    root->right->right = new_node(7);

    // Print original BST
    printf("Original BST: ");
    inorder(root);
    printf("\n");

    // Create mirror image of BST
    struct bst_node* mirror = create_mirror_image(root);

    // Print mirror image of BST
    printf("Mirror image of BST: ");
    inorder(mirror);
    printf("\n");

    return 0;
}
