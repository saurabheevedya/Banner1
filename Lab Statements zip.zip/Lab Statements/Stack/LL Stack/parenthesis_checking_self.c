#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

struct stack{
    int size;
    int top;
    char *arr;
};

int isEmpty(struct stack * ptr){
    if(ptr->top == -1){
        return 1;
    }
    else{
        return 0;
    }
}

int isFull(struct stack * ptr){
    if(ptr->top == ptr->top-1){
        return 1;
    }
    else{
        return 0;
    }
}

void push(struct stack *ptr, char val){
    if(isFull(ptr)){
        printf("Stack Overflow");
    }
    else{
        ptr->top++;
        ptr->arr[ptr->top] = val;
    }
}

int pop(struct stack * ptr){
    if(isEmpty(ptr)){
        printf("Stack Underflow");
        return -1;
    }
    else{
        char val = ptr->arr[ptr->top];
        ptr->top--;
        return val;
    }
}

char stackTop(struct stack * ptr){
    return ptr->arr[ptr->top];
}

char stackBottom(struct stack * ptr){
    return ptr -> arr[0];
}

int main(){
    struct stack *sp = (struct stack *)malloc(sizeof(struct stack));
    char str[] = "(3*((8+2)+5*(6+2))";
    sp->size = strlen(str);
    sp->top = -1;
    sp->arr = (char *)malloc(sp->size * sizeof(char));
    bool val = true;
    for(int i=0; i<strlen(str); i++){
        if(str[i] == '('){
            push(sp, '(');
        }
        else if(str[i] == ')'){
            if(isEmpty(sp)){
                val = false;
                break;
            }
            else{
                pop(sp);
            }
        }
    }
    if(val==false || isEmpty(sp)==false){
        printf("Parenthesis do not match\n");
    }
    else{
        printf("Parenthesis Match");
    }
    return 0;
}