#include <stdio.h>
#include <stdlib.h>

struct Node{
    int data;
    struct Node * next;
};

void linkedlisttravesal(struct Node * ptr){
    while(ptr!=NULL){
        printf("Data: %d \n", ptr->data);
        ptr = ptr->next;
    }
}

int isEmpty(struct Node* top){
    if(top == NULL){
        return 1;
    }
    else{
        return 0;
    }
}

int isFull(struct Node* top){
    struct Node * p = (struct Node*)malloc(sizeof(struct Node));
    if(p==NULL){
        return 1;
    }
    else{
        return 0;
    }
}

struct Node * push(struct Node * top, int x)
{
    struct Node * p = (struct Node*)malloc(sizeof(struct Node));
    if(p==NULL){
        printf("Stack Overflow\n");
        free(p);
        return NULL;
    }
    else{
        struct Node * p = (struct Node*)malloc(sizeof(struct Node));
        p->data = x;
        p->next = top;
        top = p;
        return top;
    }
}

int pop(struct Node ** top){
    if(isEmpty(*top)){
        printf("Stack Underflow\n");
        return -1;
    }
    else{
        struct Node * p = (*top);
        (*top) = (*top)->next;
        int val = p->data;
        free(p);
        return val;
    }
}

int peek(struct Node * top, int pos){
    struct Node * ptr = top;
    for(int i=0; i<pos-1 && ptr!=NULL; i++){
        ptr = ptr->next;
    }
    if(ptr!=NULL){
        return ptr->data;
    }
    else{
        return -1;
    }
}

int stackTop(struct Node * top){
    return top->data;
}

int stackBottom(struct Node * top){
    struct Node * pt = top;
    while(pt->next != NULL){
        pt = pt->next;
    }
    return pt->data;
}

int main(){
    struct Node* top =  NULL;
    top = push(top, 10);
    top = push(top, 20);
    top = push(top, 30);
    top = push(top, 40);
    top = push(top, 50);
    linkedlisttravesal(top);

    int element = pop(&top);
    printf("Popped Element: %d\n", element);
    linkedlisttravesal(top);
    top = push(top, 50);
    for(int i=1; i<=5; i++){

    printf("the element at position %d is: %d\n", i, peek(top, i));
    }
    printf("Top element: %d\n", stackTop(top));
    printf("Bottom element: %d\n", stackBottom(top));
    return 0;
}



