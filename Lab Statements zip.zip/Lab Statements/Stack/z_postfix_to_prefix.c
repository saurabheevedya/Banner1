#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Finding: stackTop operation when top == -1, returns Shift Out character, with ASCII valuye 14
// arr[-1] is assigned 14 ASCII value when its memory is dinamically allocated
// and is assigned 00, i.e., NULL character, when memory is locally allocated

struct stack2{
    int size;
    int top;
    char ** arr;
};

int isEmpty(struct stack2 *ptr)
{
    if (ptr->top == -1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void printstack(struct stack2 * ptr){
    if(isEmpty(ptr)){
        printf("Stack is Empty \n");
        return;
    }
    for(int i = ptr->top; i>=0; i--){
        printf("%d: %s ",i, ptr->arr[i]);
    }printf("\n");
}

int isFull(struct stack2 *ptr)
{
    if (ptr->top == ptr->size - 1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void push(struct stack2 *ptr, char * val)
{
    if (isFull(ptr))
    {
        printf("Stack Overflow");
    }
    else
    {
        ptr->top++;
        ptr->arr[ptr->top] = (char *)malloc((strlen(val) + 1) * sizeof(char));
        strcpy(ptr->arr[ptr->top], val);
        
    }
}

char * pop(struct stack2 *ptr)
{
    if (isEmpty(ptr))
    {
        printf("Stack Underflow");
        return "\0";
    }
    else
    {
        char * val = ptr->arr[ptr->top];
        ptr->top--;
        return val;
    }
}

char * stackTop(struct stack2 * ptr){
    return ptr->arr[ptr->top];
}

char * stackBottom(struct stack2 * ptr){
    return ptr -> arr[0];
}

// Operator check
int isOperator(char ch){
    if(ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '^' || ch == '%' || ch == '(' || ch == ')'){
        return 1;
    }
    else{
        return 0;
    }
}

// Reverse:
char * reverse(char * str){
    int n = strlen(str);
    char * rev = (char *)malloc((n + 1) * sizeof(char *));
    for(int i=0; i<n; i++){
        rev[i] = str[n-i-1];
    }
    rev[n] = '\0';
    return rev;
}

char * postfixtoprefix(char * postfix){
    struct stack2 * sp = (struct stack2 *)malloc(sizeof(struct stack2));
    sp->size = strlen(postfix);
    sp->top = -1;
    sp->arr = (char **)malloc((sp->size)*sizeof(char * ));
    for(int i=0; i< sp->size; i++){
        sp->arr[i] = (char *)malloc((sp->size + 100) * sizeof(char));
    }
    
    int i=0; // postfix iterator
    while(postfix[i] != '\0'){
        if(!isOperator(postfix[i])){
            // postfix[i] is a character, we need to convert it to char array like this
            char *arr = (char *)malloc(2 * sizeof(char));
            arr[0] = postfix[i];
            arr[1] = '\0';
            push(sp, arr);
            i++;
            // printstack(sp); // USE for seeing stepwise iteration
        }
        else if(isOperator(postfix[i])){
            // pop topmost 2 elements
            char * e1 = pop(sp);
            char * e2 = pop(sp);
            // You have to create a string, operator + e2 + e1 
            int n = strlen(e1) + strlen(e2) + 4;
            char * concat = (char *)malloc(n * sizeof(char));

            // NOTE: ALWAYS use "strcpy()" function First, while forming the concat string, as it may hold garbage values initially 

            // add operator to the string
            char * op = (char *)malloc(2 * sizeof(char));
            op[0] = postfix[i];
            op[1] = '\0';
            strcpy(concat, op);

            // add e1 to the string
            strcat(concat, e2);

            // add e2 to the string
            strcat(concat, e1);

            // now push the concatinated string on top of stack
            push(sp, concat);

            i++;
        }
    }

    char * infix = pop(sp);
    return infix;
}



int main(){

    char * postfix = "acd*e/-b+";
    printf("Prefix : %s\n", postfixtoprefix(postfix));
    
    return 0;
}

// Some solutions from chatGPT:
// The problem in your code is with the usage of the local character array arr inside the postfixtoinfix function to store the single character postfix[i]. You are then passing a pointer to this local array to the push function, which is causing undefined behavior as this array goes out of scope as soon as the loop iterates to the next character.
// To solve this problem, you need to dynamically allocate memory for each character array that you push onto the stack. You can use the malloc function to allocate memory for each character array of size 2 (to store the character and the null terminator) and copy the single character to this memory using strcpy.