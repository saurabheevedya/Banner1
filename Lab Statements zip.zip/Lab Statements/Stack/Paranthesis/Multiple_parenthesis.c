#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// '\0' marks the end of string, if an only if you are storing a string in a char array
// if you store "harsh" in a char array of size 100, it will store '\0' at index 5

struct stack
{
    int size;
    int top;
    char *arr;
};

int isEmpty(struct stack *ptr)
{
    if (ptr->top == -1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int isFull(struct stack *ptr)
{
    if (ptr->top == ptr->top - 1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void push(struct stack *ptr, char val)
{
    if (isFull(ptr))
    {
        printf("Stack Overflow");
    }
    else
    {
        ptr->top++;
        ptr->arr[ptr->top] = val;
    }
}

int pop(struct stack *ptr)
{
    if (isEmpty(ptr))
    {
        printf("Stack Underflow");
        return -1;
    }
    else
    {
        char val = ptr->arr[ptr->top];
        ptr->top--;
        return val;
    }
}

int match(char a, char b){
    if( (a == '(' && b == ')') || (a=='[' && b==']') || (a=='{' && b=='}') ){
        return 1;
    }
    else{
        return 0;
    }
}

int parenthesisMatch(char *exp)
{
    struct stack *sp;
    sp->size = strlen(exp);
    sp->top = -1;
    sp->arr = (char *)malloc(sp->size * sizeof(char));
    char popped;
    // printf(sp->arr[sp->size]);

    for (int i = 0; exp[i]!='\0'; i++)
    {
        // printf("hii ");
        if (exp[i] == '(' || exp[i] == '[' || exp[i] == '{')
        {
            push(sp, exp[i]);
        }
        else if (exp[i] == ')')
        {
            if (isEmpty(sp))
            {
                return 0;
            }
            else
            {
                popped = pop(sp);
                if(!match(popped, exp[i])){
                    return 0;
                }
            }
        }
        
    }
    
    if (isEmpty(sp))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int main()
{
    char * exp = "((((((";
    if (parenthesisMatch(exp))
    {
        printf("Parenthesis is Matching");
    }
    else
    {
        printf("Parenthesis is not Matching");
    }

    return 0;
}


