#include <stdio.h>
#include <stdlib.h>

struct Node{
    int data;
    struct Node * next;
};

struct Node * f = NULL;
struct Node * r = NULL; 
// Declaring pointers globally as enque and deque return nothing, they are just taking the copies of pointers
// While implementing linked lists, the heads were returned 

void linkedListTraversal(struct Node *ptr)
{
    printf("Printing the elements of this linked list\n");
    while (ptr != NULL)
    {
        printf("Element: %d\n", ptr->data);
        ptr = ptr->next;
    }
}

void enque(int val){
    struct Node * n = (struct Node *)malloc(sizeof(struct Node));
    if(n==NULL){
        printf("Queue is Full, element cannt be inserted\n");
    }
    else{
        n->data = val;
        n->next = NULL;
        if(f==NULL){
            f = r = n;
        }
        else{
            r->next = n;
            r = n;
        }
    }

}

int deque(){
    int val = -1;
    if(f==NULL){
        printf("Queue is empty, element cannot be deleted\n");
    }
    else{
        struct Node * ptr = f;
        f = f->next;
        val = ptr->data;
        free(ptr);
    }
    return val;
}

int main(){
    printf("Dequeuing element %d: \n", deque());
    enque(15);
    enque(25);
    enque(35);
    enque(45);
    linkedListTraversal(f);
    printf("Dequeuing element %d: \n", deque());
    printf("Dequeuing element %d: \n", deque());
    linkedListTraversal(f);
    
}