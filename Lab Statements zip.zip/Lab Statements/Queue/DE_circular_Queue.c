#include <stdio.h>
#include <stdlib.h>

struct circularqueue{
    int size;
    int f;
    int r;
    int * arr;
};

int isFull(struct circularqueue * q){
    if((q->r+1)%(q->size) == q->f){
        return 1;
    }
    return 0;
}

int isEmpty(struct circularqueue * q){
    if(q->r == q->f){
        return 1;
    }
    return 0;
}

void enqueR(struct circularqueue * q, int val){
    if(isFull(q)){
        printf("The circularqueue is Full, element %d cannot be added\n", val);
    }
    else{
        q->r = (q->r+1) % (q->size);
        q->arr[q->r] = val;
        printf("Enqued element: %d at index %d\n", val, q->r);
    }

}

int dequeF(struct circularqueue * q){
    int a = -1;
    if(isEmpty(q)){
        printf("The queue is Empty, element can't be deleted\n");
    }
    else{
        q->f = (q->f +1) % (q->size);
        a = q->arr[q->f];
    }
    return a;
}

// Extra Functions:
void enqueF(struct circularqueue * q, int val){
    if(isFull(q)){
        printf("The circularqueue is Full, element %d cannot be added\n", val);
    }
    else{
        if(q->f == 0){
            q->arr[q->f] = val;
            printf("Enqued element: %d at index %d\n", val, q->f);
            q->f = q->size - 1;
        }
        else{
            q->arr[q->f] = val;
            printf("Enqued element: %d at index %d\n", val, q->f);
            q->f--;
        }
    }
}

int dequeR(struct circularqueue * q){
    int a = -1;
    if(isEmpty(q)){
        printf("The queue is Empty, element can't be deleted\n");
    }
    else{
        if(q->r == 0){
            a = q->arr[q->r];
            q->r = q->size - 1;
        }
        else{
            a = q->arr[q->r];
            q->r--;
        }
    }
    return a;
}

void printQueue(struct circularqueue * q){
    if(q->f < q->r){
        for(int i = q->f+1; i <= q->r; i++){
            printf("%d ", q->arr[i]);
        }
    }
    else if(q->f > q->r){
        for(int i = q->f+1; i <= q->size - 1; i++){
            printf("%d ", q->arr[i]);
        }
        for(int i = 0; i <= q->r; i++){
            printf("%d ", q->arr[i]);
        }
    }printf("\n");
}

int main(){
    struct circularqueue q;
    q.size = 6;
    q.f = q.r = 0; // initialise them with zero in case of circular queue, -1 in case of linear queue
    q.arr = (int *)malloc(q.size * sizeof(int));
    enqueR(&q, 12);
    enqueR(&q, 15);
    enqueR(&q, 20);
    enqueR(&q, 45);
    enqueR(&q, 55);
    enqueR(&q, 65);
    if(isFull(&q)){
        printf("IsFull \n");
    }
    printf("Dequeuing element %d\n", dequeF(&q));
    printf("Dequeuing element %d\n", dequeF(&q));
    printf("Dequeuing element %d\n", dequeF(&q));
    if(isEmpty(&q)){
        printf("IsEmpty \n");
    }
    enqueR(&q, 90);
    enqueR(&q, 100);

    printQueue(&q);

    enqueF(&q, 14);
    printQueue(&q);
    dequeR(&q);

    printQueue(&q);

    return 0;
}