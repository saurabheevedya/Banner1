#include <stdio.h>
#include <stdlib.h>

// #include <iostream>
// using namespace std;
#define COUNT 5


struct Node{
    int key;
    struct Node *left;
    struct Node *right;
    int height;
};

struct Node * createNode(int key){
    struct Node * p = (struct Node *)malloc(sizeof(struct Node));
    p->key = key;
    p->left = NULL;
    p->right = NULL;
    p->height = 1;

    return p;
}

int getHeight(struct Node * p){
    if(p == NULL)
        return 0;
    return p->height;
}

int getBalanceFactor(struct Node * p){
    if(p == NULL)
        return 0;
    return ( getHeight(p->left) - getHeight(p->right) );
}

int maximum(int a, int b){
    return (a>b)?a:b;
}

struct Node * LeftRotate(struct Node * x){
    struct Node * y = x->right;
    struct Node * T = y->left;

    y->left = x;
    x->right = T;

    x->height = 1 + maximum(getHeight(x->left), getHeight(x->right));
    y->height = 1 + maximum(getHeight(y->left), getHeight(y->right));

    return y;
}

struct Node * RightRotate(struct Node * y){
    struct Node * x = y->left;
    struct Node * T = x->right;

    x->right = y;
    y->left = T;

    y->height = 1 + maximum(getHeight(y->left), getHeight(y->right));
    x->height = 1 + maximum(getHeight(x->left), getHeight(x->right));

    return x;
}

struct Node * insert(struct Node * node, int key){
    if(node == NULL)
        return createNode(key);   

    if(key < node->key){
        node->left = insert(node->left, key);
    }
    else if(key > node->key){
        node->right = insert(node->right, key);
    }

    node->height = 1 + maximum(getHeight(node->left), getHeight(node->right));
    int bf = getBalanceFactor(node);

    if(bf > 1 && key < node->left->key){
        return RightRotate(node);
    }
    if(bf < -1 && key > node->right->key){
        return LeftRotate(node);
    }
    if(bf > 1 && key > node->left->key){
        node->left = LeftRotate(node->left);
        return RightRotate(node);
    }
    if(bf < -1 && key < node->right->key){
        node->right = RightRotate(node->right);
        return LeftRotate(node);
    }
    return node;
}

void preOrder(struct Node *root)
{
    if(root != NULL)
    {
        printf("%d ", root->key);
        preOrder(root->left);
        preOrder(root->right);
    }
}
void inOrder(struct Node *root)
{
    if(root != NULL)
    {
        inOrder(root->left);
        printf("%d ", root->key);
        inOrder(root->right);
    }
}
void postOrder(struct Node *root)
{
    if(root != NULL)
    {
        postOrder(root->left);
        postOrder(root->right);
        printf("%d ", root->key);
    }
}

//  Code for printing the BST:

// It does reverse inorder traversal
void print2DUtil(struct Node* root, int space)
{
    // Base case
    if (root == NULL)
        return;
 
    // Increase distance between levels
    space += COUNT;
 
    // Process right child first
    print2DUtil(root->right, space);
 
    // Print current node after space
    // count
    // printf("\n");
    for (int i = COUNT; i < space; i++)
        printf(" ");
    printf("%d\n", root->key);
 
    // Process left child
    print2DUtil(root->left, space);
}
 
// Wrapper over print2DUtil()
void print2D(struct Node* root)
{
    // Pass initial space count as 0
    print2DUtil(root, 0);
}



int main(){
    struct Node * root = NULL;
    root = insert(root, 20);
    root = insert(root, 15);
    root = insert(root, 5);
    root = insert(root, 7);
    root = insert(root, 6);
    root = insert(root, 1);
    root = insert(root, 30);
    
    printf("Pre Order Traversal: ");
    preOrder(root);
    printf("\n");
    printf("In Order Traversal: ");
    inOrder(root);
    printf("\n");
    printf("Post Order Traversal: ");
    postOrder(root);
    printf("\n");

    print2D(root);

}
