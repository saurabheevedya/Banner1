#include <stdio.h>
#include <stdlib.h>
                                 
struct Node{
    int data;
    struct Node * left;
    struct Node * right;
    int lbit;
    int rbit;
};

struct Node * root = NULL;

void insert(struct Node * root, struct Node * node){
    if(node->data < root->data){
        if(root->lbit == 0){
            node->left = root->left;
            root->left = node;
            root->lbit = 1;
            node->right = root;
        }
        else{
            insert(root->left, node);
        }
    }
    else if(node->data > root->data){
        if(root->rbit == 0){
            node->right = root->right;
            root->right = node;
            root->rbit = 1;
            node->left = root;
        }
        else{
            insert(root->right, node);
        }
    }
}

void createNode(int key){
    struct Node * node = (struct Node *)malloc(sizeof(struct Node));
    node->data = key;
    node->left = NULL;
    node->right = NULL;
    node->lbit = 0;
    node->rbit = 0;
    node != NULL;
    if(root == NULL){
        struct Node * dummy = (struct Node *)malloc(sizeof(struct Node));
        root = node;
        dummy->data = 999;
        dummy->left = root;
        dummy->right = dummy;
        dummy->lbit = 1;
        dummy->rbit = 1;

        root->left = dummy;
        root->right = dummy;
    }
    else{
        insert(root, node);
    }
}

void preorder(struct Node * root){
    
    if(root->lbit == 1 && root->rbit == 1){
        printf("%d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
    else if(root->lbit == 1 && root->rbit == 0){
        printf("%d ", root->data);
        preorder(root->left);
    }
    else if(root->lbit == 0 && root->rbit == 1){
        printf("%d ", root->data);
        preorder(root->right);
    }
    else{
        printf("%d ", root->data);
    }
}
void postorder(struct Node * root){
    
    if(root->lbit == 1 && root->rbit == 1){
        postorder(root->left);
        postorder(root->right);
        printf("%d ", root->data);
    }
    else if(root->lbit == 1 && root->rbit == 0){
        postorder(root->left);
        printf("%d ", root->data);
    }
    else if(root->lbit == 0 && root->rbit == 1){
        postorder(root->right);
        printf("%d ", root->data);
    }
    else{
        printf("%d ", root->data);
    }
}

void inorder(struct Node * root){
    
    if(root->lbit == 1 && root->rbit == 1){
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
    else if(root->lbit == 1 && root->rbit == 0){
        inorder(root->left);
        printf("%d ", root->data);
    }
    else if(root->lbit == 0 && root->rbit == 1){
        printf("%d ", root->data);
        inorder(root->right);
    }
    else{
        printf("%d ", root->data);
    }

}


int main(){
    // struct Node * root = NULL;
    createNode( 20);
    createNode( 15);
    createNode( 25);
    createNode( 7);
    createNode( 10);
    createNode( 19);
    printf("Preorder Traversal: \n");
    preorder(root);
    printf("\n");
    printf("Inorder Traversal: \n");
    inorder(root);
    printf("\n");
    printf("Postorder Traversal: \n");
    postorder(root);
    printf("\n");
}