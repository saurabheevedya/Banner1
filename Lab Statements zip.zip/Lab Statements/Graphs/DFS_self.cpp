#include <stdio.h>
#include <stdlib.h>

void dfs(int visited[], int a[][7], int i){
    visited[i] = 1;
    printf("%d ", i);

    for(int j=0; j<7; j++){
        if(a[i][j] == 1 && visited[j] == 0){
            dfs(visited, a, j);  
        }
    }
}

int main(){
    // BFS Implementation : We are using "Adjacency Matrix" here
    int visited[7] = {0,0,0,0,0,0,0};
    int a[7][7] = {
        {0,1,1,1,0,0,0},
        {1,0,1,0,0,0,0},
        {1,1,0,1,1,0,0},
        {1,0,1,0,1,0,0},
        {0,0,1,1,0,1,1},
        {0,0,0,0,1,0,0}, 
        {0,0,0,0,1,0,0}
    };
    int i=6; // element from where we start
    // bool visall = false;
    printf("DFS Traversal: ");
    dfs(visited, a, i);

}