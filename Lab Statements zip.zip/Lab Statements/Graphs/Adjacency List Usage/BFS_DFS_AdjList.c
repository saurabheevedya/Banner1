#include <stdio.h>
#include <stdlib.h>
#define MAX_VERTICES 50

//In the given code, graph->array is a pointer to an array of AdjList structures. Each AdjList structure has a member named head which is a pointer to the first node of the linked list. So, when we initialize each adjacency list as empty, we make the head pointer NULL, which indicates that there are no nodes in the linked list.

//If we initialize graph->array[i] to NULL, we will lose the pointer to the head of the linked list, which will result in a segmentation fault when we try to add nodes to the linked list. This is because we will be dereferencing a null pointer when we try to access graph->array[i].head in addEdge function.

//Hence, it is necessary to initialize graph->array[i].head to NULL in order to create an empty linked list for each vertex of the graph.

// <------ Queue Implementation 
struct queue{
    int size;
    int f;
    int r;
    int * arr;
};

int isFull(struct queue * q){
    if(q->r == q->size -1){
        return 1;
    }
    return 0;
}

int isEmpty(struct queue * q){
    if(q->r == q->f){
        return 1;
    }
    return 0;
}

void enque(struct queue * q, int val){
    if(isFull(q)){
        printf("The queue is Full, element cannot be added\n");
    }
    else{
        q->r++;
        q->arr[q->r] = val;
    }

}

int deque(struct queue * q){
    int a = -1;
    if(isEmpty(q)){
        printf("The queue is Empty, element can't be deleted\n");
    }
    else{
        q->f++;
        a = q->arr[q->f];
    }
    return a;
}

// Queue Implementation Complete -------->

// A structure to represent an adjacency list node
struct AdjListNode{
    int dest;
    struct AdjListNode * next;
};

// A structure to represent an adjacency list
struct AdjList{
    struct AdjListNode * head;
};

// A structure to represent a graph. A graph
// is an array of adjacency lists.
// Size of array will be V (number of vertices
// in graph)
struct Graph{
    int V;
    struct AdjList * array;
};

struct AdjListNode * newAdjListNode(int dest){
    struct AdjListNode * newNode = (struct AdjListNode *)malloc(sizeof(struct AdjListNode));
    newNode->dest = dest;
    newNode->next = NULL;
    return newNode;
}

struct Graph * createGraph(int V){
    struct Graph * graph = (struct Graph *)malloc(sizeof(struct Graph));
    graph->V = V;
    // Create an array of adjacency lists.  Size of
    // array will be V
    graph->array = (struct AdjList *)malloc(V * sizeof(struct AdjList));
    for(int i=0; i<V; i++){
        graph->array[i].head = NULL;
    }
    return graph;
}

void addEdge(struct Graph * graph, int src, int dest){
    struct AdjListNode * check = NULL;
    struct AdjListNode * newNode = newAdjListNode(dest);

    // Add an edge from src to dest.  A new node is
    // added to the adjacency list of src.  The node
    // is added at the beginning
    if(graph->array[src].head == NULL){
        graph->array[src].head = newNode;
    }
    else{
        check = graph->array[src].head;
        while(check->next != NULL){
            check = check->next;
        }
        check->next = newNode;
    }

    // Since graph is undirected, add an edge from
    // dest to src also
    newNode = newAdjListNode(src);
    if(graph->array[dest].head == NULL){
        graph->array[dest].head = newNode;
    }
    else{
        check = graph->array[dest].head;
        while(check->next != NULL){
            check = check->next;
        }
        check->next = newNode;
    }
}

void printGraph(struct Graph * graph){
    for(int i=0; i<graph->V; i++){
        struct AdjListNode * node = graph->array[i].head;
        printf("Adjacency List of vertex %d ", i);
        while(node){
            printf("-> %d ", node->dest);
            node = node->next;
        }
        printf("\n");
    }
}

void bfs_adj(struct Graph * graph, int i, int visited[]){
    struct queue * q;
    q->size = 400;
    q->f = q->r = 0;
    q->arr = (int *)malloc(q->size * sizeof(int));

    visited[i] = 1;
    printf("%d ", i);
    enque(q, i);
    int node;

    while(!isEmpty(q)){
        node = deque(q);
        struct AdjListNode * head = graph->array[node].head;
        while(head && visited[head->dest] == 0){
            printf("%d ", head->dest);
            visited[head->dest] = 1;
            enque(q, head->dest);
            head = head->next;
        }
    }
    printf("\n");
}

void dfs_adj(struct Graph * g, int i, int visited[]){
    visited[i] = 1;
    printf("%d ", i);

    struct AdjListNode * head = g->array[i].head;
    while(head != NULL){
        // struct AdjListNode * head2 = g->array[head->dest].head;
        if(visited[head->dest] == 0){
            dfs_adj(g, head->dest, visited);
        }
        head = head->next;
    }
}

int main(){
    int V = 7;
    int visited[MAX_VERTICES] = {0};
    struct Graph * g = createGraph(V);
    addEdge(g, 0, 1);
    addEdge(g, 0, 2);
    addEdge(g, 0, 3);
    addEdge(g, 1, 2);
    addEdge(g, 2, 3);
    addEdge(g, 2, 4);
    addEdge(g, 3, 4);
    addEdge(g, 4, 5);
    addEdge(g, 4, 6);
    // print adjacency list:
    printGraph(g);

    printf("BFS Traversal: ");
    bfs_adj(g, 6, visited);

    for(int i=0; i<MAX_VERTICES; i++){
        visited[i] = 0;
    }
    printf("DFS Traversal: ");
    dfs_adj(g, 6, visited);

    return 0;
}