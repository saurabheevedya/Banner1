#include <stdio.h>
#include <limits.h>
#include <stdbool.h>
// MST and SPG(Shortest Path Graph) are different
#define V 6

int minimumVertex(int value[V], bool processed[V]){
    int min = INT_MAX;
    int vertex;
    for(int i=0; i<V-1; i++){
        if(processed[i] == false && value[i] < min){
            min = value[i];
            vertex = i;
        }
    }
    return vertex;
}

void dijkstra(int graph[V][V], int src){
    int parent[V]; //Stores Shortest Path Structure
    int value[V]; //Keeps shortest path values to each vertex from source
    bool processed[V]; //TRUE->Vertex is processed
    for(int i=0; i<V; i++){
        value[i] = INT_MAX;
        processed[i] = false;
    }

    //Assuming start point as Node-0
    parent[0] = -1;
    value[src] = 0;

    //Include (V-1) edges to cover all V-vertices
    for(int i=0; i<V-1; i++){
        //Select best Vertex by applying greedy method
        int U = minimumVertex(value, processed);
        processed[U] = true;

        //Relax adjacent vertices
        for(int j=0; j<V; j++){
            /* 3 conditions to relax:-
			      1.Edge is present from U to j.
			      2.Vertex j is not included in shortest path graph
			      3.Edge weight is smaller than current edge weight
			*/
            if(graph[U][j] != 0 && processed[j] == false && value[U] < INT_MAX && (value[U] + graph[U][j] < value[j])){
                value[j] = value[U] + graph[U][j];
                parent[j] = U;
            }
        }
    }
     
    for(int i=1; i<V; i++){
        printf("Edge %d: %d -> %d weight: %d length: %d\n", i, parent[i], i, graph[parent[i]][i], value[i]);
    }
    // No need to print parent[i] for 0, as parent[0] = -1, as graph[i][parant[i]] will give random value
}

int main(){
    int graph[V][V] = {
        {0, 1, 4, 0, 0, 0},
		{1, 0, 4, 2, 7, 0},
		{4, 4, 0, 3, 5, 0},
		{0, 2, 3, 0, 4, 6},
		{0, 7, 5, 4, 0, 7},
		{0, 0, 0, 6, 7, 0}
    };
    int src = 0;
    dijkstra(graph, src);
    return 0;
}

//TIME COMPLEXITY: O(V^2)
//TIME COMPLEXITY: (using Min-Heap + Adjacency_List): O(ElogV)