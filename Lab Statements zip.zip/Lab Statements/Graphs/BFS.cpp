#include <stdio.h>
#include <stdlib.h>

struct queue{
    int size;
    int f;
    int r;
    int * arr;
};

int isFull(struct queue * q){
    if(q->r == q->size -1){
        return 1;
    }
    return 0;
}

int isEmpty(struct queue * q){
    if(q->r == q->f){
        return 1;
    }
    return 0;
}

void enque(struct queue * q, int val){
    if(isFull(q)){
        printf("The queue is Full, element cannot be added\n");
    }
    else{
        q->r++;
        q->arr[q->r] = val;
    }
}

int deque(struct queue * q){
    int a = -1;
    if(isEmpty(q)){
        printf("The queue is Empty, element can't be deleted\n");
    }
    else{
        q->f++;
        a = q->arr[q->f];
    }
    return a;
}

int main(){
    // Initialising the queue (Array Implementation) 
    struct queue q;
    q.size = 400;
    q.f = q.r = 0;
    q.arr = (int *)malloc(q.size * sizeof(int)); 

    // BFS Implementation : We are using "Adjacency Matrix" here 
    int node;
    int visited[7] = {0,0,0,0,0,0,0}; 
    int a[7][7] = {
        {0,1,1,1,0,0,0},
        {1,0,1,0,0,0,0},
        {1,1,0,1,1,0,0},
        {1,0,1,0,1,0,0},
        {0,0,1,1,0,1,1},
        {0,0,0,0,1,0,0},
        {0,0,0,0,1,0,0}   
    };
    printf("BFS Traversal: ");
    int i = 6; // the node from which we start, you may start from any node 
    printf("%d ", i);
    visited[i] = 1;
    enque(&q, i);
    while(!isEmpty(&q)){
        int node = deque(&q);
        for (int j = 0; j < 7; j++)
        {
            if(a[node][j] == 1 && visited[j] == 0){
                printf("%d ", j);
                visited[j] = 1;
                enque(&q, j);
            }
        }
        
    }

    return 0;
}



