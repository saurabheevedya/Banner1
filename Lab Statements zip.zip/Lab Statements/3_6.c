#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define MAX_SIZE 100

char stack[MAX_SIZE];
int top = -1;

void push(char item) {
    if (top >= MAX_SIZE - 1) {
        printf("Stack Overflow\n");
        exit(1);
    }
    stack[++top] = item;
}

char pop() {
    if (top < 0) {
        printf("Stack Underflow\n");
        exit(1);
    }
    return stack[top--];
}

int isOperator(char c) {
    if (c == '+' || c == '-' || c == '*' || c == '/')
        return 1;
    else
        return 0;
}

void convertPrefixToInfix(char *prefix, char *infix) {
    int i, j, len;
    int op1, op2;
    char operator;

    len = strlen(prefix);
    for (i = len - 1; i >= 0; i--) {
        if (isOperator(prefix[i])) {
            operator = prefix[i];
            op1 = pop();
            op2 = pop();
            sprintf(infix, "(%s%c%s)", op1, operator, op2);
            push(infix);
        } else {
            push(prefix[i]);
        }
    }
}

int evaluateInfix(char *infix) {
    int i, op1, op2, result;
    char operator;
    for (i = 0; infix[i] != '\0'; i++) {
        if (isdigit(infix[i]))
            push(infix[i] - '0');
        else if (infix[i] == '(')
            push(infix[i]);
        else if (infix[i] == ')') {
            while (stack[top] != '(') {
                op2 = pop();
                operator = pop();
                op1 = pop();
                switch (operator) {
                    case '+':
                        push(op1 + op2);
                        break;
                    case '-':
                        push(op1 - op2);
                        break;
                    case '*':
                        push(op1 * op2);
                        break;
                    case '/':
                        push(op1 / op2);
                        break;
                }
            }
            pop();
        } else if (isOperator(infix[i])) {
            while (top >= 0 && stack[top] != '(' && (isOperator(stack[top]) && infix[i] <= stack[top])) {
                op2 = pop();
                operator = pop();
                op1 = pop();
                switch (operator) {
                    case '+':
                        push(op1 + op2);
                        break;
                    case '-':
                        push(op1 - op2);
                        break;
                    case '*':
                        push(op1 * op2);
                        break;
                    case '/':
                        push(op1 / op2);
                        break;
                }
            }
            push(infix[i]);
        }
    }
    while (top >= 0) {
        op2 = pop();
        operator = pop();
        op1 = pop();
        switch (operator) {
            case '+':
                push(op1 + op2);
                break;
            case '-':
                push(op1 - op2);
                break;
            case '*':
                push(op1 * op2);
                break;
            case '/':
                push(op1 / op2);
                break;
        }
    }
    result = pop();
    return result;
}

int main() {
    char prefix[MAX_SIZE], infix[MAX_SIZE];
    int result;

    printf("Enter a prefix expression: ");
    gets(prefix);

    convertPrefixToInfix(prefix, infix);
    printf("Infix expression: %s\n", infix);

    result = evaluateInfix(infix);
    printf("Result: %d\n", result);

    return 0;
}