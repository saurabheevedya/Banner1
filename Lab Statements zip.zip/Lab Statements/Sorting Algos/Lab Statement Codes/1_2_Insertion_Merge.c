#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Student {
    char name[50];
    int rollNo;
    float marks;
};

// Function to swap two students
void swap(struct Student* a, struct Student* b) {
    struct Student temp = *a;
    *a = *b;
    *b = temp;
}

// Function to perform Insertion Sort on the array of students
int insertionSort(struct Student arr[], int n) {
    int i, j, swapCount = 0;
    struct Student key;
    for (i = 1; i < n; i++) {
        key = arr[i];
        j = i - 1;
        while (j >= 0 && arr[j].rollNo > key.rollNo) {
            arr[j + 1] = arr[j];
            j--;
            swapCount++;
        }
        arr[j + 1] = key;
    }
    return swapCount;
}

// Function to perform Merge Sort on the array of students
int merge(struct Student arr[], int l, int m, int r) {
    int i, j, k, swapCount = 0;
    int n1 = m - l + 1;
    int n2 = r - m;
    struct Student L[n1], R[n2];
    for (i = 0; i < n1; i++) {
        L[i] = arr[l + i];
    }
    for (j = 0; j < n2; j++) {
        R[j] = arr[m + 1 + j];
    }
    i = 0;
    j = 0;
    k = l;
    while (i < n1 && j < n2) {
        if (L[i].rollNo <= R[j].rollNo) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
            swapCount += (n1 - i);
        }
        k++;
    }
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
    return swapCount;
}

int mergeSort(struct Student arr[], int l, int r) {
    int swapCount = 0;
    if (l < r) {
        int m = l + (r - l) / 2;
        swapCount += mergeSort(arr, l, m);
        swapCount += mergeSort(arr, m + 1, r);
        swapCount += merge(arr, l, m, r);
    }
    return swapCount;
}

int main() {
    struct Student students[] = {
        {"John Doe", 101, 85.0},
        {"Jane Smith", 103, 92.0},
        {"Bob Johnson", 105, 78.0},
        {"Mary Brown", 107, 88.0},
        {"Jim Green", 109, 80.0},
        {"Karen White", 102, 96.0},
        {"Mike Davis", 104, 70.0},
        {"Lisa Lee", 106, 91.0},
        {"Tim Jones", 108, 82.0},
        {"Sarah Black", 110, 95.0}
    };
    struct Student students2[] = {
        {"John Doe", 101, 85.0},
        {"Jane Smith", 103, 92.0},
        {"Bob Johnson", 105, 78.0},
        {"Mary Brown", 107, 88.0},
        {"Jim Green", 109, 80.0},
        {"Karen White", 102, 96.0},
        {"Mike Davis", 104, 70.0},
        {"Lisa Lee", 106, 91.0},
        {"Tim Jones", 108, 82.0},
        {"Sarah Black", 110, 95.0}
    };
    int n = sizeof(students) / sizeof(students[0]);
    int i, swapCount;

    printf("Before sorting:\n");
    for (i = 0; i < n; i++) {
        printf("%s %d %f\n", students[i].name, students[i].rollNo, students[i].marks);
    }
    printf("\n");

    // Perform Insertion Sort
    swapCount = insertionSort(students, n);
    printf("After Insertion Sort:\n");
    for (i = 0; i < n; i++) {
        printf("%s %d %f\n", students[i].name, students[i].rollNo, students[i].marks);
    }
    printf("Number of swaps: %d\n\n", swapCount);

    // Perform Merge Sort
    swapCount = mergeSort(students2, 0, n - 1);
    printf("After Merge Sort:\n");
    for (i = 0; i < n; i++) {
        printf("%s %d %f\n", students[i].name, students[i].rollNo, students[i].marks);
    }
    printf("Number of swaps: %d\n", swapCount);

    return 0;
}