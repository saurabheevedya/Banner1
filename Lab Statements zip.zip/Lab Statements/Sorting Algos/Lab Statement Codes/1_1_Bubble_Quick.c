#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Student record structure
struct Student {
    char name[50];
    int rollNo;
    float marks;
};

// Function to swap two Student structures
void swap(struct Student* a, struct Student* b) {
    struct Student temp = *a;
    *a = *b;
    *b = temp;
}

// Bubble Sort implementation
int bubbleSort(struct Student arr[], int n) {
    int i, j, swapCount = 0;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (arr[j].rollNo > arr[j + 1].rollNo) {
                swap(&arr[j], &arr[j + 1]);
                swapCount++;
            }
        }
    }
    return swapCount;
}

// Quick Sort implementation
int quickSort(struct Student arr[], int low, int high) {
    int i = low, j = high, swapCount = 0;
    int pivot = arr[(low + high) / 2].rollNo;

    while (i <= j) {
        while (arr[i].rollNo < pivot)
            i++;

        while (arr[j].rollNo > pivot)
            j--;

        if (i <= j) {
            swap(&arr[i], &arr[j]);
            swapCount++;
            i++;
            j--;
        }
    };

    if (low < j)
        swapCount += quickSort(arr, low, j);

    if (i < high)
        swapCount += quickSort(arr, i, high);

    return swapCount;
}

int main() {
    struct Student students[] = {
        {"John Doe", 101, 85.0},
        {"Jane Smith", 103, 92.0},
        {"Bob Johnson", 105, 78.0},
        {"Mary Brown", 107, 88.0},
        {"Jim Green", 109, 80.0},
        {"Karen White", 102, 96.0},
        {"Mike Davis", 104, 70.0},
        {"Lisa Lee", 106, 91.0},
        {"Tim Jones", 108, 82.0},
        {"Sarah Black", 110, 95.0}
    };

    int n = sizeof(students) / sizeof(students[0]);
    int i, bubbleSwapCount, quickSwapCount;

    // Display the unsorted array
    printf("Unsorted Array:\n");
    for (i = 0; i < n; i++) {
        printf("%d. %s - Roll No: %d, Marks: %.2f\n", i + 1, students[i].name, students[i].rollNo, students[i].marks);
    }

    // Sort the array using Bubble Sort
    bubbleSwapCount = bubbleSort(students, n);

    // Display the sorted array using Bubble Sort
    printf("\nSorted Array using Bubble Sort:\n");
    for (i = 0; i < n; i++) {
        printf("%d. %s - Roll No: %d, Marks: %.2f\n", i + 1, students[i].name, students[i].rollNo, students[i].marks);
    }
    printf("Number of Swaps performed: %d\n", bubbleSwapCount);

    // Sort the array using Quick Sort
    quickSwapCount = quickSort(students, 0, n - 1);

    // Display the sorted array using Quick Sort
    printf("\nSorted Array using Quick Sort:\n");
    for (i = 0; i < n; i++) {
        printf("%d. %s - Roll No: %d, Marks: %.2f\n", i + 1, students[i].name, students[i].rollNo, students[i].marks);
    }
    printf("Number of Swaps performed: %d\n", quickSwapCount);

    return 0;
}