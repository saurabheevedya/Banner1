#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Student {
    char name[50];
    int rollNo;
    float marks;
};

// Function to perform Insertion Sort
int insertionSort(struct Student arr[], int n) {
    int i, j, swapCount = 0;
    struct Student temp;

    for (i = 1; i < n; i++) {
        temp = arr[i];
        j = i - 1;
        while (j >= 0 && arr[j].rollNo > temp.rollNo) {
            arr[j + 1] = arr[j];
            j--;
            swapCount++;
        }
        arr[j + 1] = temp;
    }

    return swapCount;
}

// Function to partition the array for Quick Sort
int partition(struct Student arr[], int low, int high, int *swapCount) {
    struct Student pivot = arr[high];
    int i = low - 1, j;
    struct Student temp;

    for (j = low; j < high; j++) {
        if (arr[j].rollNo < pivot.rollNo) {
            i++;
            temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
            (*swapCount)++;
        }
    }

    temp = arr[i + 1];
    arr[i + 1] = arr[high];
    arr[high] = temp;
    (*swapCount)++;
    return i + 1;
}

// Function to perform Quick Sort
void quickSort(struct Student arr[], int low, int high, int *swapCount) {
    if (low < high) {
        int pi = partition(arr, low, high, swapCount);
        quickSort(arr, low, pi - 1, swapCount);
        quickSort(arr, pi + 1, high, swapCount);
    }
}

int main() {
    struct Student students[] = {
        {"John Doe", 101, 85.0},
        {"Jane Smith", 103, 92.0},
        {"Bob Johnson", 105, 78.0},
        {"Mary Brown", 107, 88.0},
        {"Jim Green", 109, 80.0},
        {"Karen White", 102, 96.0},
        {"Mike Davis", 104, 70.0},
        {"Lisa Lee", 106, 91.0},
        {"Tim Jones", 108, 82.0},
        {"Sarah Black", 110, 95.0}
    };

    int n = sizeof(students) / sizeof(students[0]);
    int i, swapCount;

    printf("Before sorting:\n");
    for (i = 0; i < n; i++) {
        printf("%s %d %f\n", students[i].name, students[i].rollNo, students[i].marks);
    }
    printf("\n");

    // Perform Insertion Sort
    swapCount = insertionSort(students, n);
    printf("After Insertion Sort:\n");
    for (i = 0; i < n; i++) {
        printf("%s %d %f\n", students[i].name, students[i].rollNo, students[i].marks);
    }
    printf("Number of swaps: %d\n\n", swapCount);

    // Perform Quick Sort
    swapCount = 0;
    quickSort(students, 0, n - 1, &swapCount);
    printf("After Quick Sort:\n");
    for (i = 0; i < n; i++) {
        printf("%s %d %f\n", students[i].name, students[i].rollNo, students[i].marks);
    }
    printf("Number of swaps: %d\n\n", swapCount);

    return 0;
}
