#include <stdio.h>
#include<string.h>

struct stud{
    char emp_name[20];
    int emp_no;
    int emp_salary;
};

void swap(struct stud *s,int i,int j)
{
    char tempenm[100];
    strcpy(tempenm,s[i].emp_name);
    strcpy(s[i].emp_name,s[j].emp_name);
    strcpy(s[j].emp_name,tempenm);

    int tempid=s[i].emp_no;
    s[i].emp_no=s[j].emp_no;
    s[j].emp_no=tempid;

    int tempsal=s[i].emp_salary;
    s[i].emp_salary=s[j].emp_salary;
    s[j].emp_salary=tempsal;
}

int partition(struct stud *s, int low, int high ){

    int pivot = s[low].emp_no;
    int i = low + 1;
    int j = high;
    int temp; 

    do{
        while(s[i].emp_no<= pivot){
            i++;
        }
        while(s[j].emp_no> pivot){
            j--;
        }
        if(i<j){
            swap(s,i,j);
        }

    }while(i<j);

    swap(s,low,j);
     
    return j ;
}

void QuickSort(struct stud *s, int low , int high){
    int partitionIndex;
     
    if (low<high){
        partitionIndex = partition(s,low , high);
        QuickSort(s, low , partitionIndex -1);
        QuickSort(s, partitionIndex+ 1, high);
    }
}

void merge(struct stud *s, int mid, int low , int high){
    int i, j ,k , id[100], sal[100];
    char name[4][100];
    i=low;
    j = mid+1;
    k = low ;

    while(i<= mid && j<= high)
    {
        if (s[i].emp_no<s[j].emp_no)
        {
            id[k] = s[i].emp_no;
            sal[k] = s[i].emp_salary;
            strcpy(name[k],s[i].emp_name);
            i++;
            k++;
        }
        else
        {
            id[k] = s[j].emp_no;
            sal[k] = s[j].emp_salary;
            strcpy(name[k],s[j].emp_name);
            j++;
            k++;
        }
    }
    while(i<=mid)
    {
        id[k] = s[i].emp_no;
        sal[k] = s[i].emp_salary;
        strcpy(name[k],s[i].emp_name);
        k++;
        i++;
    }
    while(j<=high)
    {
        id[k] = s[j].emp_no;
        sal[k] = s[j].emp_salary;
        strcpy(name[k],s[j].emp_name);
        k++;
        j++;
    }
    for(int i = low ; i<= high; i++){
        s[i].emp_no = id[i];
        s[i].emp_salary = sal[i];
        strcpy(s[i].emp_name,name[i]);
    }
}

void mergeSort(struct stud *s, int low , int high){
    int mid;
    if(low<high){
        mid = (low+high)/2;
        mergeSort(s,low,mid);
        mergeSort(s,mid +1 , high);
        merge(s,mid, low,high);
    }
}

void heapify(struct stud *s, int n, int i){
    int largest =i;
    int left = 2*i +1;
    int right = 2*i +2;

    if(left<n && s[left].emp_no>s[largest].emp_no)
        largest = left;

    if(right <n && s[right].emp_no>s[largest].emp_no)
        largest = right;
    
    if(largest!= i){
        swap(s,i,largest);
        heapify(s,n,largest);
    }
}

void heapSort(struct stud *s, int n){
    for(int i = n/2 - 1;i>=0;i--)
        heapify(s,n,i);
    
    for(int i =n-1;i>=0;i--){
        swap(s,i,0);
        heapify(s,i,0);
    }
}


void iterate(struct stud *s)
{
    for(int i=0;i<3;i++)
    {
        printf("Name :%s ,Emp_no :%d and emp_salary :%d\n",s[i].emp_name,s[i].emp_no,s[i].emp_salary);
    }
}

int main(){
    
    struct stud s[3];
    for (int i =0; i<3 ; i++){
        printf("Enter NAME, EMPLOYEE NO and SALARY of employee %d\n",(i+1));
        scanf("%s %d %d",&s[i].emp_name,&s[i].emp_no, &s[i].emp_salary);
    }
    printf("\nSorting using Quicksort :\n");
    QuickSort(s,0,2);
    iterate(s);

    printf("\nSorting using mergesort :\n");
    mergeSort(s,0,2);
    iterate(s);

    printf("\nSorting using heapsort :\n");
    heapSort(s,2);
    iterate(s);
}