#include <stdio.h>
 
// Function to swap the position of two elements
 
void swap(int* a, int* b)
{
 
    int temp = *a;
 
    *a = *b;
 
    *b = temp;
}

void heapify(int * A, int n, int i){
    int largest = i;
    int left = 2*i + 1;
    int right = 2*i + 2;

    if(left < n && A[left] > A[largest]){
        largest = left;
    }
    if(right < n && A[right] > A[largest]){
        largest = right;
    }

    if(largest != i){
        swap(&A[largest], &A[i]);
        heapify(A, n, largest);
    }
}

void heapSort(int * A, int n){
    for(int i=2*n-1; i>=0; i--){
        heapify(A, n, i);
    }
    for(int i = n-1; i >= 0; i--){
        swap(&A[i], &A[0]);
        heapify(A, i, 0);
    }
}

// A utility function to print array of size n
void printArray(int arr[], int N)
{
    for (int i = 0; i < N; i++)
        printf("%d ", arr[i]);
    printf("\n");
}
 
// Driver's code
int main()
{
    int arr[] = { 12, 11, 13, 5, 6, 7 };
    int N = sizeof(arr) / sizeof(arr[0]);
 
    // Function call
    heapSort(arr, N);
    printf("Sorted array is\n");
    printArray(arr, N);
}
 