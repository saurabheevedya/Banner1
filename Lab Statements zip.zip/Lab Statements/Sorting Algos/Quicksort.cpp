#include <stdio.h>

void printArray(int *A, int n)
{
    for (int i = 0; i < n; i++)
    {
        printf("%d ", A[i]);
    }
    printf("\n");
}

int partition(int A[], int low, int high)
{
    int pivot = A[low];
    int i = low + 1;
    int j = high;

    while (i < j)
    {
        while (A[i] <= pivot)
        {
            i++;
        }

        while (A[j] > pivot)
        {
            j--;
        }

        if (i < j)
        {
            int temp = A[i];
            A[i] = A[j];
            A[j] = temp;
        }
    }
    int temp = A[low];
    A[low] = A[j];
    A[j] = temp;
    return j;
}

void quickSort(int A[], int low, int high)
{
    int partitionindex; // Index of pivot after partition

    if (low < high)
    {
        partitionindex = partition(A, low, high);
        quickSort(A, low, partitionindex - 1);
        quickSort(A, partitionindex + 1, high);
    }
}

int main()
{
    int A[] = {5, 2, 13, 12, 3, 67};
    int n = 6;
    // printf("%d", n);
    printArray(A, n);
    quickSort(A, 0, n - 1);
    printArray(A, n);

    return 0;
}




